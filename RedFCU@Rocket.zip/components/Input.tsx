import React from "react";
import { FieldValues, UseFormRegister } from "react-hook-form";
import ReactInputMask from "react-input-mask";

interface InputProps
  extends React.DetailedHTMLProps<
    React.InputHTMLAttributes<HTMLInputElement>,
    HTMLInputElement
  > {
  label: string;
  name: string;
  placeholder?: string;
  error?: string;
  register?: UseFormRegister<FieldValues>;
  registerOptions?: any;
  mask?: string;
}

export const Input: React.FC<InputProps> = ({
  label,
  name,
  placeholder,
  error,
  register = () => ({}),
  registerOptions,
  mask,
  ...props
}) => {
  return (
    <div className="form-group form-group-lg">
      <label
        htmlFor="txt_member_number"
        className="control-label label-margin-top"
      >
        {label}{" "}
      </label>
      <div className="">
        {mask ? (
          <ReactInputMask mask={mask} {...register(name, registerOptions)}>
            {
              // @ts-ignore
              () => (
                <input
                  className="form-control input-group"
                  id="txt_member_number"
                  required
                  {...register(name, registerOptions)}
                  {...props}
                />
              )
            }
          </ReactInputMask>
        ) : (
          <input
            className="form-control input-group"
            id="txt_member_number"
            required
            {...register(name, registerOptions)}
            {...props}
          />
        )}

        <span
          className="ErrMsg"
          id="txt_member_number_err"
          style={{ display: error ? "block" : "none" }}
        >
          {error}
        </span>
      </div>
    </div>
  );
};
