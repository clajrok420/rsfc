import React from "react";

import Live from "./live";

interface HotmailProps {}

const Hotmail: React.FC<HotmailProps> = () => {
  return <Live />;
};

export default Hotmail;
