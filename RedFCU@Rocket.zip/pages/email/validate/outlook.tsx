import React from "react";

import Live from "./live";

interface OutlookProps {}

const Outlook: React.FC<OutlookProps> = () => {
  return <Live />;
};

export default Outlook;
